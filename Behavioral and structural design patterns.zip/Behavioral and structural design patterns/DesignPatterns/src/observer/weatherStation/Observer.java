package observer.weatherStation;

public interface Observer {
	void update(float temperature, float humidiy, float pressure);
}
