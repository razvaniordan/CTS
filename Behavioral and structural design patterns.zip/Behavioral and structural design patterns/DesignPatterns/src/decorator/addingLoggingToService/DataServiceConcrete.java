package decorator.addingLoggingToService;

public class DataServiceConcrete implements DataService {
	public String fetchData() {
		return "Data";
	}
}
