package decorator.addingLoggingToService;

public interface DataService {
	String fetchData();
}

