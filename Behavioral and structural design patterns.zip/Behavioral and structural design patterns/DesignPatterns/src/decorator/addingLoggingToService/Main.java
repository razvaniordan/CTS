package decorator.addingLoggingToService;

public class Main {

	public static void main(String[] args) {
		// Usage
		DataService myDataService = new LoggingDecorator(new DataServiceConcrete());
		System.out.println(myDataService.fetchData());
		
		// Create the actual data service object
		DataService realDataService = new DataServiceConcrete();
		
		// Decorate the realDataService with LoggingDecorator
		DataService loggedDataService = new LoggingDecorator(realDataService);
		
		// Use the decorated service to fetch data
		String data = loggedDataService.fetchData();
		System.out.println("Data Retrieved: " + data);
	}
}
