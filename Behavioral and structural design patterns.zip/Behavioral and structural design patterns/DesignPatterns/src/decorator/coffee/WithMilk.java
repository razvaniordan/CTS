package decorator.coffee;

public class WithMilk implements Coffee {
	private Coffee decoratedCoffee;
	
	public WithMilk(Coffee coffee) {
		decoratedCoffee = coffee;
	}

	@Override
	public String getDescription() {
		return decoratedCoffee.getDescription() + ", milk";
	}

	@Override
	public double cost() {
		return decoratedCoffee.cost() + 0.5;
	}
}
