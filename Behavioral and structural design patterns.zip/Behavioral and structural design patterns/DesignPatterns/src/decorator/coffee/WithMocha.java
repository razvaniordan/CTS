package decorator.coffee;

public class WithMocha implements Coffee {
	private Coffee decoratedCoffee;
	
	public WithMocha(Coffee coffee) {
		decoratedCoffee = coffee;
	}

	@Override
	public String getDescription() {
		return decoratedCoffee.getDescription() + ", mocha";
	}

	@Override
	public double cost() {
		return decoratedCoffee.cost() + 1.5;
	}
	
	
}
