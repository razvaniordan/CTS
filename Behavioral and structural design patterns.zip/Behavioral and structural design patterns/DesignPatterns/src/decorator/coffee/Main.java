package decorator.coffee;

public class Main {

	public static void main(String[] args) {
		Coffee myCoffee = new SimpleCoffee();
		System.out.println("Description: " + myCoffee.getDescription());
        System.out.println("Cost: $" + myCoffee.cost());
        
		myCoffee = new WithMilk(myCoffee);
		System.out.println("Description: " + myCoffee.getDescription());
        System.out.println("Cost: $" + myCoffee.cost());
        
		myCoffee = new WithMocha(myCoffee);
		
		System.out.println("Description: " + myCoffee.getDescription());
        System.out.println("Cost: $" + myCoffee.cost());
	}

}
