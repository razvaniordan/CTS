package proxy.creditcard;

public interface Payment {
	void pay(int amount);
}
