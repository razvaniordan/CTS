package proxy.image;

public interface Image {
	public void display();
}
