package adapter.fileReaderSystems;

public interface DataReader {
	String readData();
}
