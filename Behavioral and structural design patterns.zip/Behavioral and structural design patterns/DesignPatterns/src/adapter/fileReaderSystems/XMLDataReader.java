package adapter.fileReaderSystems;

public class XMLDataReader {
	String readXML() {
		return "Data from XML";
	}
}
