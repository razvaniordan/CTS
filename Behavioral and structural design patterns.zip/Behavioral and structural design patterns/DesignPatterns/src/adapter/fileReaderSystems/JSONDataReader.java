package adapter.fileReaderSystems;

public class JSONDataReader {
	String readJSON() {
		return "Data from JSON";
	}
}
