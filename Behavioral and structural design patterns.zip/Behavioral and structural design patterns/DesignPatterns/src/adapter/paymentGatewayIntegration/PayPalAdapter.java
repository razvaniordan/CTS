package adapter.paymentGatewayIntegration;

public class PayPalAdapter implements PaymentProcessor {
	private PayPal paypal;
	
	public PayPalAdapter(PayPal paypal) {
		this.paypal = paypal;
	}

	@Override
	public void processPayment(double sum) {
		System.out.println("Payment sent with paypal of sum: " + sum);
	}
}
