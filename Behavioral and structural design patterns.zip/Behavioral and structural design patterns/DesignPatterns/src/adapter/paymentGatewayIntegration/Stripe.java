package adapter.paymentGatewayIntegration;

public class Stripe {
	void makePayment(double sum) {}
}
