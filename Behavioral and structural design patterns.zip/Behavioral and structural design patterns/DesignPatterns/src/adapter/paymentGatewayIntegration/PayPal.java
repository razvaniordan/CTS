package adapter.paymentGatewayIntegration;

public class PayPal {
	void sendPayment(double sum) {}
}
