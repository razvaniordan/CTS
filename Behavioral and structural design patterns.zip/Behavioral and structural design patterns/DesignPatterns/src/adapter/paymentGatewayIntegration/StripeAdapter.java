package adapter.paymentGatewayIntegration;

public class StripeAdapter implements PaymentProcessor {
	private Stripe stripe;
	
	public StripeAdapter(Stripe stripe) {
		this.stripe = stripe;
	}

	@Override
	public void processPayment(double sum) {
		System.out.println("Payment processed with stripe of sum: " + sum);
	}
	
	
}
