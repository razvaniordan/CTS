package adapter.paymentGatewayIntegration;

public class Main {

	public static void main(String[] args) {
		PaymentProcessor paypalAdapter = new PayPalAdapter(new PayPal());
		PaymentProcessor stripeAdapter = new StripeAdapter(new Stripe());
		
		paypalAdapter.processPayment(300);
		stripeAdapter.processPayment(100);
	}

}
