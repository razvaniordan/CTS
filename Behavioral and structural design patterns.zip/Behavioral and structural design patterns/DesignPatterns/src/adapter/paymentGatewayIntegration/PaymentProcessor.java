package adapter.paymentGatewayIntegration;

public interface PaymentProcessor {
	void processPayment(double sum);
}
