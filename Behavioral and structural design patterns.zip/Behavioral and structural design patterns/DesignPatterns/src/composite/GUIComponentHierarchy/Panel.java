package composite.GUIComponentHierarchy;

import java.util.ArrayList;
import java.util.List;

public class Panel implements GUIComponent {
	private String name;
	private List<GUIComponent> items = new ArrayList<>();
	
	public Panel(String name) {
		this.name = name;
	}

	@Override
	public void draw() {
		System.out.println("Panel: " + name);
		for (GUIComponent item : items)
			item.draw();
	}
	
	public void addItem(GUIComponent item) {
		items.add(item);
	}
	
	
}
