package composite.GUIComponentHierarchy;

public class Button implements GUIComponent {
	private String name;
	
	public Button(String name) {
		this.name = name;
	}

	@Override
	public void draw() {
		System.out.println("Button drew: " + name);
	}
}
