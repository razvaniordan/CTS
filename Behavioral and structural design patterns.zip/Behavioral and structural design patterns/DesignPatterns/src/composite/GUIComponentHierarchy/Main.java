package composite.GUIComponentHierarchy;

public class Main {

	public static void main(String[] args) {
		Panel panel = new Panel("Panel 1");
		
		Button button1 = new Button("Red button");
		Button button2 = new Button("Green button");
		Button button3 = new Button("Blue button");
		
		panel.addItem(button1);
		panel.addItem(button2);
		
		Panel panel2 = new Panel("Panel 2");
		panel2.addItem(button3);
		
		panel.addItem(panel2);
		
		panel.draw();
	}

}
