package composite.GUIComponentHierarchy;

public interface GUIComponent {
	void draw();
}
