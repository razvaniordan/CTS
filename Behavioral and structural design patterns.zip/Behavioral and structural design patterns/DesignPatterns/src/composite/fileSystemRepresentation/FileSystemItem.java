package composite.fileSystemRepresentation;

public interface FileSystemItem {
	void printName();
}
