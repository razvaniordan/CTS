package composite.fileSystemRepresentation;

public class Main {

	public static void main(String[] args) {
		File file1 = new File("File1.txt");
		File file2 = new File("File2.docx");
		File file3 = new File("File3.pdf");
		
		Directory rootDirectory = new Directory("Root directory");
		
		rootDirectory.addItem(file1);
		rootDirectory.addItem(file2);
		
		Directory subDirectory = new Directory("Sub directory");
		
		subDirectory.addItem(file3);
		
		rootDirectory.addItem(subDirectory);
		
		rootDirectory.printName();
		
		
	}

}
