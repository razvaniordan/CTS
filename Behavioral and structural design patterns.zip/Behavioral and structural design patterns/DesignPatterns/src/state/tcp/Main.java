package state.tcp;

public class Main {

	public static void main(String[] args) {

		TCPConnection connection = new TCPConnection();
		
		connection.close();
		connection.acknowledge();
		connection.open();
		connection.acknowledge();
		connection.close();
	}

}
