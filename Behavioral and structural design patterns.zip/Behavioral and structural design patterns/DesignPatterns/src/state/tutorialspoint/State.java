package state.tutorialspoint;

public interface State {
	public void doAction();
}
