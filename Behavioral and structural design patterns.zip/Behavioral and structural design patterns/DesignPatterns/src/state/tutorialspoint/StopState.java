package state.tutorialspoint;

public class StopState implements State {

	@Override
	public void doAction() {
		System.out.println("Stop state");
	}

}
