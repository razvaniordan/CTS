package state.tutorialspoint;

public class Main {

	public static void main(String[] args) {
		Context context = new Context(new StartState());
		context.gestate();
		
		context.setState(new StopState());
		context.gestate();
	}

}
