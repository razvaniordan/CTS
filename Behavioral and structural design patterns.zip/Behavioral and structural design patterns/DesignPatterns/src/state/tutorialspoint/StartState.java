package state.tutorialspoint;

public class StartState implements State {

	@Override
	public void doAction() {
		System.out.println("Action when we have start state.");
	}
	
}
