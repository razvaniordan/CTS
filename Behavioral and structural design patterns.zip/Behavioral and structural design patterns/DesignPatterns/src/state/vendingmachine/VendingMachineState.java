package state.vendingmachine;

public interface VendingMachineState {
	public void handleRequest();
}
