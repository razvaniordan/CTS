/**
 * 
 */
/**
 * @author Alex
 *
 */
module DesignPatterns {
}