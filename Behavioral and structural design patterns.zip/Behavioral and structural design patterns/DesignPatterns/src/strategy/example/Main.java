package strategy.example;

public class Main {

	public static void main(String[] args) {
		OperationContext strategy = new OperationContext(new OperationAdd());
		strategy.doOperation(5, 3);
		strategy.setStrategy(new OperationMultiply());
		strategy.doOperation(5, 3);
		
		OperationContext strategy2 = new OperationContext(new OperationSubstract());
		strategy2.doOperation(5, 3);
		
	}

}
