package strategy.example;

public class OperationContext {
	private OperationInterface strategy;
	
	public OperationContext(OperationInterface strategy) {
		this.strategy = strategy;
	}

	public void setStrategy(OperationInterface strategy) {
		this.strategy = strategy;
	}
	
	public void doOperation(int num1, int num2) {
		System.out.println(strategy.doOperation(num1, num2));
	}
}
