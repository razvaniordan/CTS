package recap;

public class TCPOpenState implements TCPState {

	@Override
	public void open() {
		System.out.println("Already open");
	}

	@Override
	public void close() {
		System.out.println("System will be closed.");
		
	}

	@Override
	public void acknowledge() {
		// TODO Auto-generated method stub
		
	}

}
