package recap;

public interface TCPState {
	public void open(TCPConnection connection);
	public void close(TCPConnection connection);
	public void acknowledge(TCPConnection connection);
}
