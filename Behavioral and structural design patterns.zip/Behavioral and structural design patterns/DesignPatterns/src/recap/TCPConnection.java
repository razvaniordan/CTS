package recap;

public class TCPConnection {
	private TCPState state;
	
	public void setState(TCPState state) {
		this.state = state;
	}
	
	
}
